

export const addRegisteredGetter = () => {
  const bo
}