<template lang="pug">
.discord 
  .link Discuss or look for a player to play with on 
    a(href="https://discord.gg/5c28SZNtff" target="about:blank") discord 

</template>
