export default {
    ShareWare: 'ShareWare',
    Registered: 'Registered'
}