export type NameValue = {
  name: string
  value: string
}