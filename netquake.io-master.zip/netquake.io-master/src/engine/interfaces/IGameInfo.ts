export default interface IGameInfo {
  hostname: string
  players: number
  maxplayers: number

}