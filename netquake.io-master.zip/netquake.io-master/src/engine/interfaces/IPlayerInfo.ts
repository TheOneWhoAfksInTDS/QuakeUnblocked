export default interface IPlayerInfo {
  name: string,
  shirtColor: number,
  pantColor: number,
  frags: number,
  connectedTime: number
}