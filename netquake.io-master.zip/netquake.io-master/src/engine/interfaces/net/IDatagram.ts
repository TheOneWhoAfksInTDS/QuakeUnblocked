export default interface IDatagram {
  data: ArrayBuffer,
  cursize: number
}