export default interface IPackedFile {
  name: string,
  filepos: number,
  filelen: number
}