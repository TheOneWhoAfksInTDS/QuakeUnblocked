import {init} from '../../engine/sys'
import * as ServerSys from './sys'

init('', ServerSys)